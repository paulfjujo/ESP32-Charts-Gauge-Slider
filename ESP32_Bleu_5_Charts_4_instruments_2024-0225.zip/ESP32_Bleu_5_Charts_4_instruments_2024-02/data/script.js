﻿// see example project :
// https://randomnerdtutorials.com/esp32-plot-readings-charts-multiple/
//see RNTLab forum
// rev 24-02-2024
// rev 22-11-2022   enlevé MCP23017 car non raccordé
// rev 24-06-2022
// Get current sensor readings when the page loads
var gateway = `ws://${window.location.hostname}/ws`
var websocket
window.addEventListener('load', getReadings)

// Create Temperature Chart
var chartT = new Highcharts.Chart({
  time: { useUTC: false }, // correction time axe des X
  chart: {
    borderColor: '#EBBA95',
    borderRadius: 20,
    borderWidth: 2,
    type: 'line',
    marginTop: 50,
    marginBottom: 50,
    renderTo: 'chart-multiSensors',
  },

  yAxis: [
    {
      // Primary yAxis
      minorGridLineDashStyle: 'longdash',
      minorTickInterval: 'auto',
      minorTickWidth: 0,
      minorGridLineColor: '#C5EEFA',

      labels: {
        format: '{value}*C',
        style: {
          color: '#101D42',
        },
      },
      title: {
        text: 'DS18B20 #1',
        style: {
          color: '#101D42',
        },
      },
      opposite: true,
      min: -10.0,
      max: 40.0,
    },
    {
      // Secondary yAxis
      gridLineWidth: 0,
      title: {
        text: 'Compteur',
        style: {
          color: '#00A6A6',
        },
      },
      labels: {
        format: '{value}.',
        style: {
          color: '#00A6A6',
        },
      },
      opposite: true,
      min: 0,
      max: 1000,
    },
    {
      // 3e yAxis
      gridLineWidth: 0,
      title: {
        text: 'Pression',
        style: {
          color: '#8B2635',
        },
      },
      labels: {
        format: '{value} mBar',
        style: {
          color: '#8B2635',
        },
      },
      opposite: true, // axe Y à droite
      min: 950.0,
      max: 1050.0,
    },
    {
      // 4e yAxis
      gridLineWidth: 0,
      title: {
        text: 'Temp AM2302',
        style: {
          color: '#A04035',
        },
      },
      labels: {
        format: '{value}*C',
        style: {
          color: '#A04035',
        },
      },
      opposite: false, // axe Y à gauche
      min: -10.0,
      max: 40.0,
    },
    {
      // 5e yAxis
      gridLineWidth: 0,
      title: {
        text: 'Humid AM2302',
        style: {
          color: '#3020A0',
        },
      },
      labels: {
        format: '{value} %',
        style: {
          color: '#3020A0',
        },
      },
      opposite: false, // axe Y à gauche
      min: 0.0,
      max: 100.0,
    },

   // {
      // 6e yAxis
   //   gridLineWidth: 0,
   //   title: {
   //     text: 'Mcp23017',
   //     style: {
   //       color: '#3020A0',
    //    },
   //   },
   //   labels: {
   //     format: ' {value}.',
   //     style: {
    //      color: '#3020A0',
    //    },
    //  },
   //   opposite: false, // axe Y à gauche
   //   min: 0,
   //   max: 255,
   // },
  ],
  tooltip: {
    shared: true,
  },
  legend: {
    layout: 'vertical',
    align: 'left',
    backgroundColor: '#FCFFC5',
    x: 300,
    verticalAlign: 'top',
    y: -15,
    floating: true,
  },
  series: [
    {
      name: 'DS18B20 #1',
      type: 'spline',
      yAxis: 0,
      // type: 'line',
      color: '#101D42',
      marker: {
        symbol: 'circle',
        radius: 3,
        fillColor: '#101D42',
      },
    },
    {
      name: 'Cpt',
      yAxis: 1,
      type: 'line',
      dashStyle: 'shortdot',
      color: '#00A6A6',
      marker: {
        symbol: 'square',
        radius: 3,
        fillColor: '#00A6A6',
      },
    },
    {
      name: 'Pression',
      yAxis: 2,
      type: 'line',
      color: '#8B2635',
      marker: {
        symbol: 'triangle',
        radius: 3,
        fillColor: '#8B2635',
      },
    },
    {
      name: 'Temperature',
      yAxis: 3,
      type: 'line',
      color: '#004000',
      marker: {
        symbol: 'triangle',
        radius: 3,
        fillColor: '#8BFF35',
      },
    },
    {
      name: 'Humidity',
      yAxis: 4,
      type: 'line',
      color: '#8BF0F',
      marker: {
        symbol: 'triangle',
        radius: 3,
        fillColor: '#8BF0F',
      },
    },

  //  {
  //    name: 'MCP23017',
  //    yAxis: 5,
  //    type: 'line',
  //    dashStyle: 'shortdot',
  //    color: '#101010',
   //   marker: {
   //    symbol: 'square',
    //    radius: 3,
    //    fillColor: '#00A6A6',
    //  },
   // },
  ],
  title: {
    text: undefined,
  },
  xAxis: {
    type: 'datetime',
    dateTimeLabelFormats: { second: '%H:%M:%S' },
  },
  credits: {
    enabled: false,
  },
})



var gaugePress = new RadialGauge({
  renderTo: 'gauge-pression',
  width: 200,
  height: 200,
  units: 'mBar',
  minValue: 900.0,
  maxValue: 1100.0,
  colorValueBoxRect: '#049faa',
  colorValueBoxRectEnd: '#049faa',
  colorValueBoxBackground: '#f1fbfc',
  valueInt: 2,
  majorTicks: ['900', '950', '1000', '1050', '1100'],
  minorTicks: 5,
  strokeTicks: true,
  highlights: [
    {
      from: 900.0,
      to: 950.0,
      color: '#801010',
    },
    {
      from: 1050.0,
      to: 1100.0,
      color: '#801010',
    },
  ],
  colorPlate: '#fff',
  borderShadowWidth: 0,
  borders: false,
  needleType: 'line',
  colorNeedle: '#007F80',
  colorNeedleEnd: '#007F80',
  needleWidth: 8,
  needleCircleSize: 12,
  colorNeedleCircleOuter: '#007F80',
  needleCircleOuter: true,
  needleCircleInner: false,
  animationDuration: 100,
  animationRule: 'linear',
}).draw()

var gaugeOws1 = new RadialGauge({
  renderTo: 'gauge-ows1',
  width: 200,
  height: 200,
  units: '°C',
  minValue: -10.0,
  maxValue: 40.0,
  colorValueBoxRect: '#049faa',
  colorValueBoxRectEnd: '#049faa',
  colorValueBoxBackground: '#f1fbfc',
  valueInt: 2,
  majorTicks: ['-10.0', ' 0.0', '10.0', '20.0', '30.0', '40.0'],
  minorTicks: 5,
  strokeTicks: true,
  highlights: [
    {
      from: -10,
      to: 0,
      color: '#000080',
    },
    {
      from: 35,
      to: 40,
      color: '#A00000',
    },
  ],
  colorPlate: '#fff',
  borderShadowWidth: 0,
  borders: false,
  needleType: 'line',
  colorNeedle: '#007F80',
  colorNeedleEnd: '#007F80',
  needleWidth: 4,
  needleCircleSize: 10,
  colorNeedleCircleOuter: '#007F80',
  needleCircleOuter: true,
  needleCircleInner: true,
  animationDuration: 100,
  animationRule: 'linear',
}).draw()


var gaugeTemper = new RadialGauge({
  renderTo: 'gauge-temper',
  width: 200,
  height: 200,
  units: '°C',
  minValue: -10.0,
  maxValue: 40.0,
  colorValueBoxRect: '#049faa',
  colorValueBoxRectEnd: '#049faa',
  colorValueBoxBackground: '#f1fbfc',
  valueInt: 2,
  majorTicks: ['-10.0', ' 0.0', '10.0', '20.0', '30.0', '40.0'],
  minorTicks: 5,
  strokeTicks: true,
  highlights: [
    {
      from: -10,
      to: 0,
      color: '#000080',
    },
    {
      from: 35,
      to: 40,
      color: '#A00000',
    },
  ],
  colorPlate: '#fff',
  borderShadowWidth: 0,
  borders: false,
  needleType: 'line',
  colorNeedle: '#007F80',
  colorNeedleEnd: '#007F80',
  needleWidth: 4,
  needleCircleSize: 10,
  colorNeedleCircleOuter: '#007F80',
  needleCircleOuter: true,
  needleCircleInner: true,
  animationDuration: 100,
  animationRule: 'linear',
}).draw()



var gaugeHumid = new RadialGauge({
  renderTo: 'gauge-humid',
  width: 200,
  height: 200,
  units: '%',
  minValue: 0.0,
  maxValue: 100.0,
  colorValueBoxRect: '#049faa',
  colorValueBoxRectEnd: '#049faa',
  colorValueBoxBackground: '#f1fbfc',
  valueInt: 2,
  majorTicks: ['0.0', ' 20.0', '40.0', '60.0', '80.0', '100.0'],
  minorTicks: 5,
  strokeTicks: true,
  highlights: [
    {
      from: -0.0,
      to: 40,
      color: '#000080',
    },
    {
      from: 90,
      to: 100,
      color: '#A00000',
    },
  ],
  colorPlate: '#fff',
  borderShadowWidth: 0,
  borders: false,
  needleType: 'line',
  colorNeedle: '#007F80',
  colorNeedleEnd: '#007F80',
  needleWidth: 4,
  needleCircleSize: 10,
  colorNeedleCircleOuter: '#007F80',
  needleCircleOuter: true,
  needleCircleInner: true,
  animationDuration: 100,
  animationRule: 'linear',
}).draw()

//Plot temperature in the temperature chart
function plotTemperature(jsonValue) {
  var keys = Object.keys(jsonValue)
  console.log(keys)
  console.log(keys.length)

  for (var i = 0; i < keys.length; i++) {
    var x = new Date().getTime()
    console.log(x)
    const key = keys[i]
    var y = Number(jsonValue[key])
    console.log(y)

    if (chartT.series[i].data.length > 1439) {
      chartT.series[i].addPoint([x, y], true, true, true)
    } else {
      chartT.series[i].addPoint([x, y], true, false, true)
    }
  }
}

// Function to get current readings on the webpage when it loads for the first time
function getReadings() {
  var xhr = new XMLHttpRequest()
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      var myObj = JSON.parse(this.responseText)
      console.log(myObj)
      plotTemperature(myObj)
	   gaugeOws1.value = myObj.DS18B20
      gaugePress.value = myObj.Pression
      gaugeHumid.value = myObj.Humidity    // added 23-02-2024
	   gaugeTemper.value = myObj.Temperature
    }
  }
  xhr.open('GET', '/readings', true)
  xhr.send()
}

if (!!window.EventSource) {
  var source = new EventSource('/events')

  source.addEventListener(
    'open',
    function (e) {
      console.log('Events Connected')
    },
    false,
  )

  source.addEventListener(
    'error',
    function (e) {
      if (e.target.readyState != EventSource.OPEN) {
        console.log('Events Disconnected')
      }
    },
    false,
  )

  source.addEventListener(
    'message',
    function (e) {
      console.log('message', e.data)
    },
    false,
  )

  source.addEventListener(
    'new_readings',
    function (e) {
      console.log('new_readings', e.data)
      var myObj = JSON.parse(e.data)
      console.log('myObj=')
      console.log(myObj)
      plotTemperature(myObj)
      gaugePress.value = myObj.Pression
      gaugeOws1.value = myObj.DS18B20
	  gaugeHumid.value = myObj.Humidity    // added 23-02-2024
	   gaugeTemper.value = myObj.Temperature
    },
    false,
  )
}

function onload(event) {
  initWebSocket()
  getCurrentValue1()
}


function initWebSocket() {
  console.log('Trying to open a WebSocket connection…')
  websocket = new WebSocket(gateway)
  websocket.onopen = onOpen
  websocket.onclose = onClose
  websocket.onmessage = onMessage
}

function onOpen(event) {
  console.log('Connection opened')
}

function onClose(event) {
  console.log('Connection closed')
  setTimeout(initWebSocket, 2000)
}

function onMessage(event) {
  console.log('onMessage ')
  console.log(event.data)
}


function getCurrentValue1() {
  var xhr = new XMLHttpRequest()
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById('pwmSlider1').value = this.responseText
      document.getElementById('textSliderValue1').innerHTML = this.responseText
    }
  }
  xhr.open('GET', '/currentValue1', true)
  xhr.send()
}


function updateSliderPWM() {
  var sliderValue1 = document.getElementById('pwmSlider1').value
  document.getElementById('textSliderValue1').innerHTML = sliderValue1
  console.log('update sliderValue1 : ')
  console.log(sliderValue1)
 // websocket.send('1s' + sliderValue1.toString())
   websocket.send('1s' + sliderValue1)
}
  
  
  
  
